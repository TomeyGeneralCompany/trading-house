-- Explicit dated lot resolutions and execution-P&L support for standard futures.
BEGIN;
ALTER TABLE ref_data.delivery_profiles DROP CONSTRAINT delivery_profiles_kind_check;
ALTER TABLE ref_data.delivery_profiles ADD CONSTRAINT delivery_profiles_kind_check CHECK(kind IN('uniform','exchange_published'));
-- A commodity can have explicitly authorized energy and rate units. The unit
-- dimension still has its exact FK; membership no longer forces one dimension.
DO $$ DECLARE constraint_name text;BEGIN
 SELECT conname INTO STRICT constraint_name FROM pg_constraint WHERE conrelid='ref_data.commodity_units'::regclass AND confrelid='ref_data.commodities'::regclass;
 EXECUTE format('ALTER TABLE ref_data.commodity_units DROP CONSTRAINT %I',constraint_name);
END $$;
ALTER TABLE ref_data.commodity_units ADD FOREIGN KEY(catalog_id,revision_id,commodity_code) REFERENCES ref_data.commodities(catalog_id,revision_id,code);
CREATE TABLE ref_data.futures_product_terms (
 catalog_id uuid NOT NULL,revision_id uuid NOT NULL,product_code ref_data.code NOT NULL,profile_code ref_data.code NOT NULL,index_code ref_data.code,
 PRIMARY KEY(catalog_id,revision_id,product_code),
 FOREIGN KEY(catalog_id,revision_id,product_code) REFERENCES ref_data.futures_products(catalog_id,revision_id,code),
 FOREIGN KEY(catalog_id,revision_id,profile_code) REFERENCES ref_data.delivery_profiles(catalog_id,revision_id,code),
 FOREIGN KEY(catalog_id,revision_id,index_code) REFERENCES ref_data.price_index_definitions(catalog_id,revision_id,code)
);
-- Normalize the existing unambiguous economic profile before enabling the
-- immutable guard. Conflicting recipe profiles fail the product primary key.
INSERT INTO ref_data.futures_product_terms(catalog_id,revision_id,product_code,profile_code)
 SELECT DISTINCT s.catalog_id,s.revision_id,s.product_code,c.profile_code
 FROM ref_data.futures_series s JOIN market_data.contracts k ON(k.reference_catalog_id,k.reference_revision_id,k.futures_series_code)=(s.catalog_id,s.revision_id,s.code)
 JOIN market_data.curve_members m ON(m.catalog_id,m.revision_id,m.contract_id)=(k.catalog_id,k.revision_id,k.id)
 JOIN market_data.curves c ON(c.catalog_id,c.revision_id,c.code)=(m.catalog_id,m.revision_id,m.curve_code);
CREATE TRIGGER frozen_definition BEFORE INSERT OR UPDATE OR DELETE ON ref_data.futures_product_terms FOR EACH ROW EXECUTE FUNCTION ref_data.guard_definition();
ALTER TABLE ref_data.futures_product_terms ENABLE ROW LEVEL SECURITY;
ALTER TABLE ref_data.futures_product_terms FORCE ROW LEVEL SECURITY;
CREATE POLICY scoped_read ON ref_data.futures_product_terms FOR SELECT TO openetrm_runtime USING(security.reference_access(catalog_id,'ReadMarketData') AND security.reference_version_visible(catalog_id,revision_id));
GRANT SELECT ON ref_data.futures_product_terms TO openetrm_runtime,openetrm_security_owner;
CREATE TABLE ref_data.futures_basis_settlements (
 catalog_id uuid NOT NULL,revision_id uuid NOT NULL,series_code ref_data.code NOT NULL,
 index_code ref_data.code NOT NULL,benchmark_series_code ref_data.code NOT NULL,
 implementation text NOT NULL CHECK(implementation='index_minus_future_v1'),
 PRIMARY KEY(catalog_id,revision_id,series_code),CHECK(series_code<>benchmark_series_code),
 FOREIGN KEY(catalog_id,revision_id,series_code) REFERENCES ref_data.futures_series(catalog_id,revision_id,code),
 FOREIGN KEY(catalog_id,revision_id,index_code) REFERENCES ref_data.price_index_definitions(catalog_id,revision_id,code),
 FOREIGN KEY(catalog_id,revision_id,benchmark_series_code) REFERENCES ref_data.futures_series(catalog_id,revision_id,code)
);
COMMENT ON TABLE ref_data.futures_basis_settlements IS 'Exact final-settlement references for directly quoted basis futures. Not inferred live pricing dependencies or processed settlements.';
CREATE TRIGGER frozen_definition BEFORE INSERT OR UPDATE OR DELETE ON ref_data.futures_basis_settlements FOR EACH ROW EXECUTE FUNCTION ref_data.guard_definition();
ALTER TABLE ref_data.futures_basis_settlements ENABLE ROW LEVEL SECURITY;
ALTER TABLE ref_data.futures_basis_settlements FORCE ROW LEVEL SECURITY;
CREATE POLICY scoped_read ON ref_data.futures_basis_settlements FOR SELECT TO openetrm_runtime USING(security.reference_access(catalog_id,'ReadMarketData') AND security.reference_version_visible(catalog_id,revision_id));
GRANT SELECT ON ref_data.futures_basis_settlements TO openetrm_runtime,openetrm_security_owner;
CREATE TABLE ref_data.futures_lot_resolutions (
 catalog_id uuid NOT NULL, revision_id uuid NOT NULL, series_code ref_data.code NOT NULL,
 quantity_code ref_data.code NOT NULL, amount ref_data.exact_number NOT NULL CHECK(amount>0),
 factor ref_data.exact_number NOT NULL CHECK(factor>0),
 implementation text NOT NULL CHECK(implementation IN('published_contract_size_v1','calendar_delivery_days_v1')),
 source_code ref_data.code NOT NULL,
 PRIMARY KEY(catalog_id,revision_id,series_code),
 FOREIGN KEY(catalog_id,revision_id,series_code) REFERENCES ref_data.futures_series(catalog_id,revision_id,code),
 FOREIGN KEY(catalog_id,revision_id,quantity_code) REFERENCES ref_data.quantity_specifications(catalog_id,revision_id,code),
 FOREIGN KEY(catalog_id,revision_id,source_code) REFERENCES ref_data.sources(catalog_id,revision_id,code)
);
COMMENT ON TABLE ref_data.futures_lot_resolutions IS 'Authoritative dated lot in quote units. Published exchange factors are explicit inputs, never inferred from nominal hours or ambient timezone.';
CREATE TRIGGER frozen_definition BEFORE INSERT OR UPDATE OR DELETE ON ref_data.futures_lot_resolutions FOR EACH ROW EXECUTE FUNCTION ref_data.guard_definition();
ALTER TABLE ref_data.futures_lot_resolutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ref_data.futures_lot_resolutions FORCE ROW LEVEL SECURITY;
CREATE POLICY scoped_read ON ref_data.futures_lot_resolutions FOR SELECT TO openetrm_runtime USING(security.reference_access(catalog_id,'ReadMarketData') AND security.reference_version_visible(catalog_id,revision_id));
GRANT SELECT ON ref_data.futures_lot_resolutions TO openetrm_runtime,openetrm_security_owner;
ALTER TABLE trading.futures_revision_markets DROP CONSTRAINT futures_revision_markets_implementation_check;
ALTER TABLE trading.futures_revision_markets ADD CONSTRAINT futures_revision_markets_implementation_check CHECK(implementation IN('fixed_total_cash_execution_pnl_v1','contract_lot_execution_pnl_v2'));
CREATE OR REPLACE FUNCTION security.prepare_futures_binding(catalog uuid,book uuid,revision uuid,curve text,contract uuid,
 valuation timestamptz,executed timestamptz,lots numeric,execution numeric,implementation text,ordinal integer)
 RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE q ref_data.quote_specifications;product ref_data.futures_products;series_row ref_data.futures_series;
 contract_row market_data.contracts;curve_row market_data.curves;definition_from timestamptz;starts timestamptz;ends timestamptz;side uuid;instrument uuid;
BEGIN
 IF executed IS NULL OR NOT isfinite(executed) OR valuation IS NULL OR NOT isfinite(valuation) OR (implementation IS NULL OR implementation NOT IN('fixed_total_cash_execution_pnl_v1','contract_lot_execution_pnl_v2'))
 THEN RAISE EXCEPTION 'futures_input' USING ERRCODE='P0001'; END IF;
 IF NOT EXISTS(SELECT 1 FROM trading.books b JOIN trading.portfolios p ON(p.catalog_id,p.id)=(b.catalog_id,b.portfolio_id) WHERE b.catalog_id=catalog AND b.id=book AND b.effective_at<=executed AND p.effective_at<=executed) THEN RAISE EXCEPTION 'futures_book' USING ERRCODE='P0001'; END IF;
 IF lots IS NULL OR lots<>trunc(lots) OR lots=0 OR abs(lots)>100000 THEN RAISE EXCEPTION 'futures_lots' USING ERRCODE='P0001'; END IF;
 SELECT * INTO contract_row FROM market_data.contracts WHERE catalog_id=catalog AND revision_id=revision AND id=contract;
 SELECT * INTO curve_row FROM market_data.curves WHERE catalog_id=catalog AND revision_id=revision AND code=curve;
 IF contract_row.kind IS DISTINCT FROM 'future' OR curve_row.rule IS DISTINCT FROM 'direct' OR curve_row.direct_role IS DISTINCT FROM 'daily_settlement' OR
  NOT EXISTS(SELECT 1 FROM market_data.curve_members WHERE catalog_id=catalog AND revision_id=revision AND curve_code=curve AND contract_id=contract) THEN RAISE EXCEPTION 'futures_definition' USING ERRCODE='P0001'; END IF;
 SELECT p.* INTO product FROM ref_data.futures_series s JOIN ref_data.futures_products p ON(p.catalog_id,p.revision_id,p.code)=(s.catalog_id,s.revision_id,s.product_code)
 WHERE(s.catalog_id,s.revision_id,s.code)=(contract_row.reference_catalog_id,contract_row.reference_revision_id,contract_row.futures_series_code) AND s.definition_state='synthetic';
 IF product.definition_state IS DISTINCT FROM 'synthetic' OR product.settlement_method NOT IN('cash','physical') OR
   (implementation='fixed_total_cash_execution_pnl_v1' AND(product.settlement_method<>'cash' OR product.lot_basis<>'fixed_total')) OR
   (product.lot_basis='fixed_total' AND product.lot_unit_code IS DISTINCT FROM product.quote_unit_code)
 THEN RAISE EXCEPTION 'futures_convention' USING ERRCODE='P0001'; END IF;
 SELECT * INTO series_row FROM ref_data.futures_series WHERE(catalog_id,revision_id,code)=(contract_row.reference_catalog_id,contract_row.reference_revision_id,contract_row.futures_series_code);
 IF series_row.delivery_from IS DISTINCT FROM contract_row.delivery_from OR series_row.delivery_to IS DISTINCT FROM contract_row.delivery_to OR
  curve_row.commodity_code IS DISTINCT FROM product.commodity_code OR curve_row.location_code IS DISTINCT FROM product.location_code OR
  NOT EXISTS(SELECT 1 FROM ref_data.futures_product_terms t WHERE(t.catalog_id,t.revision_id,t.product_code,t.profile_code)=(product.catalog_id,product.revision_id,product.code,curve_row.profile_code))
 THEN RAISE EXCEPTION 'futures_definition' USING ERRCODE='P0001'; END IF;
 SELECT * INTO q FROM ref_data.quote_specifications WHERE(catalog_id,revision_id,code)=(curve_row.reference_catalog_id,curve_row.reference_revision_id,curve_row.quote_code);
 IF EXISTS(SELECT 1 FROM ref_data.futures_basis_settlements b
   JOIN ref_data.futures_series benchmark ON(benchmark.catalog_id,benchmark.revision_id,benchmark.code)=(b.catalog_id,b.revision_id,b.benchmark_series_code)
   JOIN ref_data.futures_products bp ON(bp.catalog_id,bp.revision_id,bp.code)=(benchmark.catalog_id,benchmark.revision_id,benchmark.product_code)
   JOIN ref_data.price_index_definitions i ON(i.catalog_id,i.revision_id,i.code)=(b.catalog_id,b.revision_id,b.index_code)
   WHERE(b.catalog_id,b.revision_id,b.series_code)=(series_row.catalog_id,series_row.revision_id,series_row.code) AND
   (product.settlement_method<>'cash' OR EXISTS(SELECT 1 FROM ref_data.futures_product_terms t WHERE(t.catalog_id,t.revision_id,t.product_code)=(product.catalog_id,product.revision_id,product.code) AND t.index_code IS NOT NULL) OR (benchmark.delivery_from,benchmark.delivery_to) IS DISTINCT FROM(series_row.delivery_from,series_row.delivery_to) OR
    (bp.commodity_code,bp.quote_currency_code,bp.quote_unit_code,bp.quote_multiplier) IS DISTINCT FROM(product.commodity_code,product.quote_currency_code,product.quote_unit_code,product.quote_multiplier) OR
    (i.commodity_code,i.location_code,i.currency_code,i.quote_unit_code,i.quote_multiplier) IS DISTINCT FROM(product.commodity_code,product.location_code,product.quote_currency_code,product.quote_unit_code,product.quote_multiplier) OR
    EXISTS(SELECT 1 FROM ref_data.futures_basis_settlements bb WHERE(bb.catalog_id,bb.revision_id,bb.series_code)=(benchmark.catalog_id,benchmark.revision_id,benchmark.code))))
 THEN RAISE EXCEPTION 'futures_definition' USING ERRCODE='P0001'; END IF;
 IF q.kind IS DISTINCT FROM (CASE WHEN EXISTS(SELECT 1 FROM ref_data.futures_basis_settlements b WHERE(b.catalog_id,b.revision_id,b.series_code)=(series_row.catalog_id,series_row.revision_id,series_row.code)) THEN 'basis' ELSE 'outright' END) OR
  (implementation='fixed_total_cash_execution_pnl_v1' AND q.kind<>'outright') OR q.currency_code IS DISTINCT FROM product.quote_currency_code OR q.multiplier IS DISTINCT FROM product.quote_multiplier OR q.trading_tick IS DISTINCT FROM product.outright_tick_size OR
  (SELECT count(*) FROM ref_data.quantity_specifications WHERE(catalog_id,revision_id,commodity_code,unit_code)=(q.catalog_id,q.revision_id,product.commodity_code,product.quote_unit_code))<>1 OR
  NOT EXISTS(SELECT 1 FROM ref_data.quantity_specifications WHERE(catalog_id,revision_id,code,commodity_code,unit_code)=(q.catalog_id,q.revision_id,q.quantity_code,product.commodity_code,product.quote_unit_code))
 THEN RAISE EXCEPTION 'futures_convention' USING ERRCODE='P0001'; END IF;
 IF product.lot_basis='fixed_total' THEN
  IF EXISTS(SELECT 1 FROM ref_data.futures_lot_resolutions WHERE(catalog_id,revision_id,series_code)=(series_row.catalog_id,series_row.revision_id,series_row.code)) THEN RAISE EXCEPTION 'futures_lot' USING ERRCODE='P0001'; END IF;
 ELSE
  IF NOT EXISTS(SELECT 1 FROM ref_data.futures_lot_resolutions r WHERE(r.catalog_id,r.revision_id,r.series_code,r.quantity_code)=(series_row.catalog_id,series_row.revision_id,series_row.code,q.quantity_code)
    AND r.amount=product.contract_size*r.factor AND
    (r.implementation='published_contract_size_v1' OR(r.implementation='calendar_delivery_days_v1' AND product.lot_basis='per_delivery_day' AND r.factor=series_row.delivery_to-series_row.delivery_from)))
  THEN RAISE EXCEPTION 'futures_lot' USING ERRCODE='P0001'; END IF;
 END IF;
 SELECT event_at INTO starts FROM ref_data.futures_milestones WHERE(catalog_id,revision_id,series_code,milestone)=(contract_row.reference_catalog_id,contract_row.reference_revision_id,contract_row.futures_series_code,'first_trading') AND value_state='known';
 SELECT event_at INTO ends FROM ref_data.futures_milestones WHERE(catalog_id,revision_id,series_code,milestone)=(contract_row.reference_catalog_id,contract_row.reference_revision_id,contract_row.futures_series_code,'last_trading') AND value_state='known';
 IF ends IS DISTINCT FROM contract_row.expiry_at THEN RAISE EXCEPTION 'futures_definition' USING ERRCODE='P0001'; END IF;
 IF starts IS NULL OR executed<starts OR executed>=ends OR executed>valuation OR valuation<starts OR valuation>=ends OR execution IS NULL OR execution<q.minimum OR execution>q.maximum OR mod(execution,product.outright_tick_size)<>0 THEN RAISE EXCEPTION 'futures_execution' USING ERRCODE='P0001'; END IF;
 SELECT (effective_from::timestamp AT TIME ZONE 'UTC') INTO definition_from FROM market_data.revision_periods WHERE catalog_id=catalog AND revision_id=revision AND effective_from<=(executed AT TIME ZONE 'UTC')::date AND(executed AT TIME ZONE 'UTC')::date<effective_to;
 IF definition_from IS NULL OR NOT EXISTS(SELECT 1 FROM market_data.revisions WHERE catalog_id=catalog AND id=revision AND state='sealed') THEN RAISE EXCEPTION 'futures_definition' USING ERRCODE='P0001'; END IF;
 instrument=security.futures_contract_id(contract_row.reference_catalog_id,contract_row.reference_revision_id,contract_row.futures_series_code);
 IF EXISTS(SELECT 1 FROM trading.instruments i WHERE i.catalog_id=catalog AND i.id=instrument) THEN
  IF NOT EXISTS(SELECT 1 FROM trading.futures_contract_references f WHERE f.catalog_id=catalog AND f.instrument_id=instrument
   AND(f.reference_catalog_id,f.reference_revision_id,f.series_code)=(contract_row.reference_catalog_id,contract_row.reference_revision_id,contract_row.futures_series_code))
  THEN RAISE EXCEPTION 'futures_identity' USING ERRCODE='P0001'; END IF;
 ELSE
  INSERT INTO trading.instruments VALUES(catalog,instrument,ordinal,definition_from);
  INSERT INTO trading.futures_contract_references VALUES(catalog,instrument,contract_row.reference_catalog_id,contract_row.reference_revision_id,contract_row.futures_series_code,ordinal,definition_from);
 END IF;
 RETURN instrument;
END $$;
CREATE OR REPLACE FUNCTION security.book_futures_with_parties(catalog uuid,operation uuid,book uuid,revision uuid,curve text,contract uuid,
 valuation timestamptz,executed timestamptz,lots numeric,execution numeric,implementation text,trader uuid,trader_revision integer,memo text,booking jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE c security.request_contexts; prior trading.trades; request_value jsonb; ordinal integer; instrument uuid; trade uuid; binding uuid;
BEGIN
 IF NOT security.trading_access(catalog,'ReadTrades') OR NOT security.trading_access(catalog,'BookTrade') THEN RAISE EXCEPTION 'No booking access' USING ERRCODE='42501'; END IF;
 SELECT * INTO c FROM security.request_contexts WHERE backend_pid=pg_backend_pid() AND transaction_id=pg_current_xact_id_if_assigned() AND runtime_login=session_user;
 IF c.market_context_id IS NOT NULL THEN RAISE EXCEPTION 'historical_read_only' USING ERRCODE='P0001'; END IF;
 PERFORM pg_advisory_xact_lock(730849102);
 IF NOT security.trading_access(catalog,'BookTrade') THEN RAISE EXCEPTION 'Booking access expired' USING ERRCODE='42501'; END IF;
 IF operation IS NULL OR operation='00000000-0000-0000-0000-000000000000'::uuid OR executed IS NULL OR NOT isfinite(executed) OR valuation IS NULL OR NOT isfinite(valuation) OR (implementation IS NULL OR implementation NOT IN('fixed_total_cash_execution_pnl_v1','contract_lot_execution_pnl_v2')) THEN RAISE EXCEPTION 'futures_input' USING ERRCODE='P0001'; END IF;
 request_value=jsonb_build_object('book',book,'revision',revision,'curve',curve,'contract',contract,'valuation',valuation AT TIME ZONE 'UTC','executed',executed AT TIME ZONE 'UTC','lots',lots,'execution',execution,'implementation',implementation);
 request_value=request_value||jsonb_build_object('booking',booking);
 IF trader IS NOT NULL OR trader_revision IS NOT NULL OR memo IS NOT NULL THEN request_value=request_value||jsonb_build_object('trader',trader,'traderRevision',trader_revision,'memo',memo);END IF;
 SELECT * INTO prior FROM trading.trades WHERE catalog_id=catalog AND operation_id=operation;
 IF FOUND THEN
  IF prior.actor_id<>c.actor_id OR prior.request<>request_value THEN RAISE EXCEPTION 'futures_conflict' USING ERRCODE='P0001'; END IF;
  RETURN security.futures_booking_status(catalog,operation);
 END IF;
 IF EXISTS(SELECT 1 FROM trading.trade_revisions WHERE catalog_id=catalog AND operation_id=operation) THEN RAISE EXCEPTION 'futures_conflict' USING ERRCODE='P0001'; END IF;
 PERFORM security.require_trade_annotation(catalog,trader,trader_revision,memo,executed);
 PERFORM security.require_trade_parties(catalog,booking,executed);
 IF(SELECT count(*) FROM trading.trades WHERE catalog_id=catalog)>=256 THEN RAISE EXCEPTION 'futures_limit' USING ERRCODE='P0001'; END IF;
 SELECT coalesce(max(publication_order),0)+1 INTO ordinal FROM trading.publications WHERE catalog_id=catalog;
 INSERT INTO trading.publications VALUES(catalog,ordinal,pg_current_xact_id());
 instrument=security.prepare_futures_binding(catalog,book,revision,curve,contract,valuation,executed,lots,execution,implementation,ordinal);
 trade=gen_random_uuid();binding=gen_random_uuid();
 INSERT INTO trading.trades VALUES(catalog,trade,book,operation,c.actor_id,request_value,ordinal,executed);
 INSERT INTO trading.trade_instruments VALUES(catalog,trade,binding,instrument,lots,execution,'unprocessed',ordinal,executed);
 INSERT INTO trading.trade_revisions VALUES(catalog,trade,1,NULL,gen_random_uuid(),'futures_booking_state_v2','booked',book,binding,instrument,lots,execution,executed,executed,'unprocessed',operation,c.actor_id,'Initial booking',request_value,ordinal,trader,trader_revision,memo,(booking->>'tradeDate')::date,(booking->>'legalEntityId')::uuid,(booking->>'legalEntityRevision')::integer,(booking->>'counterpartyId')::uuid,(booking->>'counterpartyRevision')::integer);
 PERFORM security.retain_futures_market(catalog,trade,1,instrument,revision,curve,contract,implementation,ordinal,executed);
 IF NOT security.trading_access(catalog,'ReadTrades') OR NOT security.trading_access(catalog,'BookTrade') THEN RAISE EXCEPTION 'Booking access expired' USING ERRCODE='42501'; END IF;
 RETURN security.futures_booking_status(catalog,operation);
END $$;

CREATE OR REPLACE FUNCTION security.amend_futures_with_parties(catalog uuid,operation uuid,trade uuid,expected integer,book uuid,definition uuid,curve text,contract uuid,
 valuation timestamptz,effective timestamptz,executed timestamptz,lots numeric,execution numeric,reason text,implementation text,convention text,trader uuid,trader_revision integer,memo text,booking jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE c security.request_contexts;head trading.trade_revisions;prior trading.trade_revisions;request_value jsonb;ordinal integer;instrument uuid;binding uuid;old_side trading.futures_revision_markets;old_currency record;new_currency record;
BEGIN
 IF NOT security.trading_access(catalog,'ReadTrades') OR NOT security.trading_access(catalog,'AmendTrade') THEN RAISE EXCEPTION 'No amendment access' USING ERRCODE='42501'; END IF;
 SELECT * INTO c FROM security.request_contexts WHERE backend_pid=pg_backend_pid() AND transaction_id=pg_current_xact_id_if_assigned() AND runtime_login=session_user;
 IF c.market_context_id IS NOT NULL THEN RAISE EXCEPTION 'historical_read_only' USING ERRCODE='P0001'; END IF;
 PERFORM pg_advisory_xact_lock(730849102);
 IF NOT security.trading_access(catalog,'AmendTrade') THEN RAISE EXCEPTION 'Amendment access expired' USING ERRCODE='42501'; END IF;
 IF operation IS NULL OR operation='00000000-0000-0000-0000-000000000000'::uuid OR expected IS NULL OR expected<1 OR
  reason IS NULL OR length(btrim(reason)) NOT BETWEEN 1 AND 500 OR reason ~ '^[[:space:]]*$' OR effective IS NULL OR NOT isfinite(effective) OR effective IS DISTINCT FROM valuation OR
  convention IS DISTINCT FROM 'unprocessed_futures_booking_amendment_v1' THEN RAISE EXCEPTION 'futures_amendment' USING ERRCODE='P0001'; END IF;
 request_value=jsonb_build_object('trade',trade,'expected',expected,'book',book,'definition',definition,'curve',curve,'contract',contract,
 'valuation',valuation AT TIME ZONE 'UTC','effective',effective AT TIME ZONE 'UTC','executed',executed AT TIME ZONE 'UTC',
 'lots',lots,'execution',execution,'reason',reason,'implementation',implementation,'convention',convention);
 request_value=request_value||jsonb_build_object('booking',booking);
 IF trader IS NOT NULL OR trader_revision IS NOT NULL OR memo IS NOT NULL THEN request_value=request_value||jsonb_build_object('trader',trader,'traderRevision',trader_revision,'memo',memo);END IF;
 SELECT * INTO prior FROM trading.trade_revisions r WHERE r.catalog_id=catalog AND r.operation_id=operation;
 IF FOUND THEN
  IF prior.event_kind<>'amended' OR prior.actor_id<>c.actor_id OR prior.request<>request_value THEN RAISE EXCEPTION 'futures_conflict' USING ERRCODE='P0001'; END IF;
  RETURN security.futures_operation_status(catalog,operation);
 END IF;
 PERFORM security.require_trade_annotation(catalog,trader,trader_revision,memo,executed);
 PERFORM security.require_trade_parties(catalog,booking,executed);
 SELECT * INTO head FROM trading.trade_revisions r WHERE r.catalog_id=catalog AND r.trade_id=trade ORDER BY r.revision DESC LIMIT 1;
 IF NOT FOUND THEN RAISE EXCEPTION 'futures_trade' USING ERRCODE='P0001'; END IF;
 IF head.revision<>expected THEN RAISE EXCEPTION 'futures_revision_conflict' USING ERRCODE='P0001'; END IF;
 IF head.revision>=256 THEN RAISE EXCEPTION 'futures_limit' USING ERRCODE='P0001'; END IF;
 IF effective<head.effective_at OR head.settlement_state<>'unprocessed' THEN RAISE EXCEPTION 'futures_amendment' USING ERRCODE='P0001'; END IF;
 SELECT coalesce(max(publication_order),0)+1 INTO ordinal FROM trading.publications WHERE catalog_id=catalog;
 INSERT INTO trading.publications VALUES(catalog,ordinal,pg_current_xact_id());
 SELECT * INTO STRICT old_side FROM trading.futures_revision_markets m WHERE(m.catalog_id,m.trade_id,m.revision)=(catalog,trade,head.revision);
 IF old_side.definition_revision_id IS DISTINCT FROM definition THEN RAISE EXCEPTION 'futures_amendment' USING ERRCODE='P0001'; END IF;
 -- Validate the retained state as well: amendment is not settlement or an expiry escape.
 PERFORM security.prepare_futures_binding(catalog,head.book_id,old_side.definition_revision_id,old_side.curve_code,old_side.contract_id,
  valuation,head.execution_at,head.lots,head.execution_price,old_side.implementation,ordinal);
 SELECT q.catalog_id,q.revision_id,q.currency_code INTO old_currency FROM market_data.curves cv JOIN ref_data.quote_specifications q
 ON(q.catalog_id,q.revision_id,q.code)=(cv.reference_catalog_id,cv.reference_revision_id,cv.quote_code)
 WHERE cv.catalog_id=catalog AND cv.revision_id=definition AND cv.code=old_side.curve_code;
 SELECT q.catalog_id,q.revision_id,q.currency_code INTO new_currency FROM market_data.curves cv JOIN ref_data.quote_specifications q
 ON(q.catalog_id,q.revision_id,q.code)=(cv.reference_catalog_id,cv.reference_revision_id,cv.quote_code)
 WHERE cv.catalog_id=catalog AND cv.revision_id=definition AND cv.code=curve;
 IF old_currency IS DISTINCT FROM new_currency THEN RAISE EXCEPTION 'futures_amendment' USING ERRCODE='P0001'; END IF;
 instrument=security.prepare_futures_binding(catalog,book,definition,curve,contract,valuation,executed,lots,execution,implementation,ordinal);
 IF EXISTS(SELECT 1 FROM trading.futures_contract_references a JOIN trading.futures_contract_references b
  ON(b.catalog_id,b.reference_catalog_id,b.reference_revision_id,b.series_code)=(a.catalog_id,a.reference_catalog_id,a.reference_revision_id,a.series_code)
  WHERE(a.catalog_id,a.instrument_id,b.instrument_id)=(catalog,instrument,head.instrument_id)) THEN instrument=head.instrument_id; END IF;
 IF (book,instrument,lots,execution,executed,trader,trader_revision,memo,booking,definition,curve,contract) IS NOT DISTINCT FROM (head.book_id,head.instrument_id,head.lots,head.execution_price,head.execution_at,head.trader_id,head.trader_revision,head.memo,security.trade_party_payload(head.trade_date,head.legal_entity_id,head.legal_entity_revision,head.counterparty_id,head.counterparty_revision),old_side.definition_revision_id,old_side.curve_code,old_side.contract_id)
 THEN RAISE EXCEPTION 'futures_no_change' USING ERRCODE='P0001'; END IF;
 binding=CASE WHEN instrument=head.instrument_id THEN head.binding_id ELSE gen_random_uuid() END;
 INSERT INTO trading.trade_revisions VALUES(catalog,trade,head.revision+1,head.revision,gen_random_uuid(),'futures_booking_state_v2','amended',book,binding,instrument,lots,execution,executed,effective,
 'unprocessed',operation,c.actor_id,reason,request_value,ordinal,trader,trader_revision,memo,(booking->>'tradeDate')::date,(booking->>'legalEntityId')::uuid,(booking->>'legalEntityRevision')::integer,(booking->>'counterpartyId')::uuid,(booking->>'counterpartyRevision')::integer);
 PERFORM security.retain_futures_market(catalog,trade,head.revision+1,instrument,definition,curve,contract,implementation,ordinal,effective);
 IF NOT security.trading_access(catalog,'ReadTrades') OR NOT security.trading_access(catalog,'AmendTrade') THEN RAISE EXCEPTION 'Amendment access expired' USING ERRCODE='42501'; END IF;
 RETURN security.futures_operation_status(catalog,operation);
END $$;

CREATE OR REPLACE FUNCTION market_data.validate_revision(cat uuid, rev uuid) RETURNS void
LANGUAGE plpgsql SET search_path = pg_catalog AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM market_data.revisions m JOIN ref_data.revisions r
      ON (r.catalog_id,r.id) = (m.reference_catalog_id,m.reference_revision_id)
      WHERE m.catalog_id=cat AND m.id=rev AND r.state='sealed') THEN
    RAISE EXCEPTION 'Exact reference revision must be sealed' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.curves c
      WHERE c.catalog_id=cat AND c.revision_id=rev AND (
        NOT EXISTS (SELECT 1 FROM market_data.curve_members m WHERE
          (m.catalog_id,m.revision_id,m.curve_code)=(c.catalog_id,c.revision_id,c.code)) OR
        (SELECT count(*) FROM market_data.curve_inputs i WHERE
          (i.catalog_id,i.revision_id,i.curve_code)=(c.catalog_id,c.revision_id,c.code))
          <> CASE c.rule WHEN 'direct' THEN 0 WHEN 'add' THEN 2 ELSE 3 END OR
        (c.rule='scale_add') <> EXISTS (SELECT 1 FROM market_data.curve_inputs h WHERE
          (h.catalog_id,h.revision_id,h.curve_code)=(c.catalog_id,c.revision_id,c.code) AND h.slot='multiplier'))) THEN
    RAISE EXCEPTION 'Curve members, slots or multiplier configuration are incomplete' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.curve_inputs i
      JOIN market_data.curves c ON (c.catalog_id,c.revision_id,c.code)=(i.catalog_id,i.revision_id,i.curve_code)
      JOIN market_data.curves s ON (s.catalog_id,s.revision_id,s.code)=(i.catalog_id,i.revision_id,i.source_curve_code)
      JOIN ref_data.quote_specifications q ON (q.catalog_id,q.revision_id,q.code)=(c.reference_catalog_id,c.reference_revision_id,c.quote_code)
      JOIN ref_data.quote_specifications sq ON (sq.catalog_id,sq.revision_id,sq.code)=(s.reference_catalog_id,s.reference_revision_id,s.quote_code)
      WHERE i.catalog_id=cat AND i.revision_id=rev AND (
        q.kind <> 'outright' OR c.profile_code <> s.profile_code OR
        (i.slot='spread' AND (sq.kind <> 'basis' OR
          (q.quantity_code,q.currency_code,q.multiplier) <> (sq.quantity_code,sq.currency_code,sq.multiplier))) OR
        (i.slot='base' AND (sq.kind <> 'outright' OR (c.rule='add' AND
          (q.quantity_code,q.currency_code,q.multiplier) <> (sq.quantity_code,sq.currency_code,sq.multiplier)))) OR
        (SELECT count(*) FROM market_data.constituent_mappings m WHERE
          (m.catalog_id,m.revision_id,m.curve_code,m.slot)=(i.catalog_id,i.revision_id,i.curve_code,i.slot)) <>
        (SELECT count(*) FROM market_data.curve_members m WHERE
          (m.catalog_id,m.revision_id,m.curve_code)=(i.catalog_id,i.revision_id,i.curve_code)))) THEN
    RAISE EXCEPTION 'Incompatible quote/profile types or incomplete mappings' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.curve_members a
      JOIN market_data.curve_members b ON (b.catalog_id,b.revision_id,b.contract_id)=(a.catalog_id,a.revision_id,a.contract_id)
        AND a.curve_code < b.curve_code
      JOIN market_data.curves c ON (c.catalog_id,c.revision_id,c.code)=(a.catalog_id,a.revision_id,a.curve_code)
      JOIN market_data.curves d ON (d.catalog_id,d.revision_id,d.code)=(b.catalog_id,b.revision_id,b.curve_code)
      JOIN ref_data.quote_specifications q ON (q.catalog_id,q.revision_id,q.code)=(c.reference_catalog_id,c.reference_revision_id,c.quote_code)
      JOIN ref_data.quote_specifications z ON (z.catalog_id,z.revision_id,z.code)=(d.reference_catalog_id,d.reference_revision_id,d.quote_code)
      WHERE a.catalog_id=cat AND a.revision_id=rev AND
        (c.commodity_code,c.location_code,c.profile_code,q.quantity_code,q.currency_code,q.multiplier)
        <> (d.commodity_code,d.location_code,d.profile_code,z.quantity_code,z.currency_code,z.multiplier)) THEN
    RAISE EXCEPTION 'Contract membership cannot change common economic specifications' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.constituent_mappings m
      JOIN market_data.contracts t ON (t.catalog_id,t.revision_id,t.id)=(m.catalog_id,m.revision_id,m.target_contract_id)
      JOIN market_data.contracts s ON (s.catalog_id,s.revision_id,s.id)=(m.catalog_id,m.revision_id,m.source_contract_id)
      JOIN market_data.curve_inputs i ON (i.catalog_id,i.revision_id,i.curve_code,i.slot)=(m.catalog_id,m.revision_id,m.curve_code,m.slot)
      JOIN market_data.curves sc ON (sc.catalog_id,sc.revision_id,sc.code)=(m.catalog_id,m.revision_id,m.source_curve_code)
      WHERE m.catalog_id=cat AND m.revision_id=rev AND (
        (t.delivery_from,t.delivery_to) <> (s.delivery_from,s.delivery_to) OR
        (i.expiry_rule='freeze_final_future' AND (s.kind <> 'future' OR sc.rule <> 'direct')))) THEN
    RAISE EXCEPTION 'Unsupported delivery mapping or frozen-final source' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (WITH RECURSIVE walk AS (
      SELECT curve_code AS root, source_curve_code AS node, ARRAY[curve_code] AS visited,
        source_curve_code=curve_code AS cycle FROM market_data.curve_inputs
        WHERE catalog_id=cat AND revision_id=rev
      UNION ALL
      SELECT w.root,i.source_curve_code,w.visited || w.node,i.source_curve_code=ANY(w.visited || w.node)
        FROM walk w JOIN market_data.curve_inputs i ON i.curve_code=w.node
        WHERE i.catalog_id=cat AND i.revision_id=rev AND NOT w.cycle)
      SELECT 1 FROM walk WHERE cycle) THEN
    RAISE EXCEPTION 'Curve dependency cycle' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.curve_inputs m
      JOIN market_data.curves c ON (c.catalog_id,c.revision_id,c.code)=(m.catalog_id,m.revision_id,m.curve_code)
      JOIN market_data.curve_inputs b ON (b.catalog_id,b.revision_id,b.curve_code)=(m.catalog_id,m.revision_id,m.curve_code) AND b.slot='base'
      JOIN market_data.curves source ON (source.catalog_id,source.revision_id,source.code)=(b.catalog_id,b.revision_id,b.source_curve_code)
      JOIN ref_data.quote_specifications q ON (q.catalog_id,q.revision_id,q.code)=(c.reference_catalog_id,c.reference_revision_id,c.quote_code)
      JOIN ref_data.quote_specifications sq ON (sq.catalog_id,sq.revision_id,sq.code)=(source.reference_catalog_id,source.reference_revision_id,source.quote_code)
      LEFT JOIN market_data.series series ON (series.catalog_id,series.revision_id,series.id)=(m.catalog_id,m.revision_id,m.source_series_id)
      LEFT JOIN ref_data.value_specifications v ON (v.catalog_id,v.revision_id,v.code)=
        (c.reference_catalog_id,c.reference_revision_id,COALESCE(m.value_specification_code,series.value_specification_code))
      WHERE m.catalog_id=cat AND m.revision_id=rev AND m.slot='multiplier' AND (
        v.code IS NULL OR (q.currency_code,q.multiplier) <> (sq.currency_code,sq.multiplier) OR
        (v.kind='quantity_ratio' AND (sq.quantity_code,q.quantity_code) <> (v.numerator_quantity_code,v.denominator_quantity_code)) OR
        (v.kind='dimensionless' AND sq.quantity_code <> q.quantity_code) OR
        (m.constant_value IS NOT NULL AND (m.constant_value < v.minimum OR m.constant_value > v.maximum)))) THEN
    RAISE EXCEPTION 'Multiplier value/type is incompatible with curve inputs/output' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.curve_members member
      JOIN market_data.curves c ON (c.catalog_id,c.revision_id,c.code)=(member.catalog_id,member.revision_id,member.curve_code)
      WHERE c.catalog_id=cat AND c.revision_id=rev AND c.rule='direct' AND NOT EXISTS (
        SELECT 1 FROM market_data.series s WHERE (s.catalog_id,s.revision_id,s.contract_id,s.quote_code)=
          (c.catalog_id,c.revision_id,member.contract_id,c.quote_code))) THEN
    RAISE EXCEPTION 'Direct constituents require exact price series' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.contracts k
      JOIN ref_data.futures_series s ON (s.catalog_id,s.revision_id,s.code)=(k.reference_catalog_id,k.reference_revision_id,k.futures_series_code)
      WHERE k.catalog_id=cat AND k.revision_id=rev AND (s.definition_state='placeholder' OR
        (s.delivery_from,s.delivery_to) IS DISTINCT FROM (k.delivery_from,k.delivery_to) OR
        NOT EXISTS (SELECT 1 FROM ref_data.futures_milestones x WHERE
          (x.catalog_id,x.revision_id,x.series_code)=(s.catalog_id,s.revision_id,s.code)
          AND x.milestone='last_trading' AND x.value_state='known' AND x.event_at=k.expiry_at))) THEN
    RAISE EXCEPTION 'Futures constituent must match a specified dated series' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.curve_members m
      JOIN market_data.contracts k ON (k.catalog_id,k.revision_id,k.id)=(m.catalog_id,m.revision_id,m.contract_id)
      JOIN market_data.curves c ON (c.catalog_id,c.revision_id,c.code)=(m.catalog_id,m.revision_id,m.curve_code)
      JOIN ref_data.settlement_targets t ON (t.catalog_id,t.revision_id,t.code)=(c.reference_catalog_id,c.reference_revision_id,c.settlement_target_code)
      JOIN ref_data.quote_specifications q ON (q.catalog_id,q.revision_id,q.code)=(c.reference_catalog_id,c.reference_revision_id,c.quote_code)
      JOIN ref_data.quantity_specifications z ON (z.catalog_id,z.revision_id,z.code)=(q.catalog_id,q.revision_id,q.quantity_code)
      JOIN ref_data.delivery_profiles dp ON (dp.catalog_id,dp.revision_id,dp.code)=(c.reference_catalog_id,c.reference_revision_id,c.profile_code)
      LEFT JOIN ref_data.futures_series s ON (s.catalog_id,s.revision_id,s.code)=(k.reference_catalog_id,k.reference_revision_id,k.futures_series_code)
      LEFT JOIN ref_data.futures_products p ON (p.catalog_id,p.revision_id,p.code)=(s.catalog_id,s.revision_id,s.product_code)
      WHERE m.catalog_id=cat AND m.revision_id=rev AND (
        (t.kind='future_series' AND k.kind <> 'future') OR
        (k.kind='future' AND (p.definition_state='placeholder' OR t.kind <> 'future_series' OR q.kind <> CASE WHEN EXISTS(SELECT 1 FROM ref_data.futures_basis_settlements b WHERE(b.catalog_id,b.revision_id,b.series_code)=(s.catalog_id,s.revision_id,s.code)) THEN 'basis' ELSE 'outright' END OR
          NOT EXISTS(SELECT 1 FROM ref_data.futures_product_terms terms WHERE(terms.catalog_id,terms.revision_id,terms.product_code,terms.profile_code)=(p.catalog_id,p.revision_id,p.code,c.profile_code)) OR
          c.rule <> 'direct' OR c.direct_role IS DISTINCT FROM 'daily_settlement' OR
          (p.location_code IS NOT NULL AND p.location_code <> c.location_code) OR
          p.market_clock_code <> dp.clock_code OR p.delivery_calendar_code <> dp.calendar_code OR
          (p.commodity_code,p.quote_currency_code,p.quote_unit_code,p.quote_multiplier,p.outright_tick_size)
          IS DISTINCT FROM (c.commodity_code,q.currency_code,z.unit_code,q.multiplier,q.trading_tick))))) THEN
    RAISE EXCEPTION 'Constituent conflicts with common curve/futures specifications' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM market_data.curves c
      JOIN ref_data.settlement_targets t ON (t.catalog_id,t.revision_id,t.code)=(c.reference_catalog_id,c.reference_revision_id,c.settlement_target_code)
      JOIN ref_data.quote_specifications q ON (q.catalog_id,q.revision_id,q.code)=(c.reference_catalog_id,c.reference_revision_id,c.quote_code)
      JOIN ref_data.quantity_specifications z ON (z.catalog_id,z.revision_id,z.code)=(q.catalog_id,q.revision_id,q.quantity_code)
      JOIN ref_data.price_index_definitions x ON (x.catalog_id,x.revision_id)=(t.catalog_id,t.revision_id)
        AND x.code IN (t.index_a_code,t.index_b_code)
      WHERE c.catalog_id=cat AND c.revision_id=rev AND
        (x.commodity_code,x.currency_code,x.quote_unit_code,x.quote_multiplier)
        <> (c.commodity_code,q.currency_code,z.unit_code,q.multiplier)) THEN
    RAISE EXCEPTION 'Settlement index target has incompatible commodity/quote units' USING ERRCODE = '23514';
  END IF;
END;
$$;
COMMIT;
