# Economic lifecycle projection

D401's pure projection path retains the certified opening snapshot, its market
cutoff, knowledge cutoff and immutable connected graph. The calculation clock is
separate. Projection never appends observations, accepted settlements, payments,
trade revisions or native lifecycle events.

The pure operator cashout component selects the exact valuation mark as its
explicit contractual-price expectation. It fixes only at the declared official
role and instant, rounds the complete signed amount under the native cashout
convention, and replaces the claim with ordinary projected cash. Nominal cash
carrying or the claim's same captured currency curve is a required selection.
Fixing and payment remain separate events, including an explicit causal order
when their instants coincide. Paid-at-due and outstanding choices share the
ordinary cash pricer; hypothetical paid state cannot enter actual valuation.
Independent checks cover negative prices, nonunit quote multipliers, exact
rounding differences and conditional curve carry. Migration 0293 saves the closed
quantity-and-cashout profile with exact native position/market references. Original
requests and older same-fact acknowledgements preserve their first versions;
configuration neither mutates a prior profile nor reapplies an older fact.
Owned native checks qualify the ordinary opening, both cash dispositions and
separate historical/Monte Carlo workers with exact interactive-report parity and
no financial mutation. Source-known cashout continuation has its own qualified
accepted-quantity adapter; the hypothetical handler cannot replace an already
accepted future event.

`ILifecycleProjection` declares its native economic owner, complete transition and
possible residual price dependencies, opening ordinary valuation portfolios and
exact events. An opening unpaid obligation remains an ordinary holding. New cash
contributions belong to the event that creates them; earlier contributions cannot
be rewritten or removed. Independent native holdings use typed accounting owners,
without creating artificial trades.

Every handler retains the exact source snapshot and admits its event schedule for
the common horizon before history is read. A component prepared under another
source clock or input set cannot be reused. Potential physical branches require
their qualified delivery policies during this preparation, even when a particular
sample later abandons an option and never creates that physical future.

`CashLifecycleProjection` retains actual source-known payments as a separate
immutable collection. Those payments enter period cash at their effective
instants under both hypothetical disposition choices. A projected scheduled
payment reserves every already-known later actual allocation, so it cannot pay
the same balance twice. Opening overdue cash is never paid merely because its
due date passed. Projected discharge state has a separate type and cannot enter
an actual valuation operation. Opposite-direction refunds require their own
qualified contractual policy; the scheduled-payment profile does not invent one.

The source adapter supplies a retained selected-session version, calendar and
complete resolved close schedule. The engine chooses the first configured close
strictly after opening, shared by every market partition. An absent next close is
unavailable. Historical and Monte Carlo scenario rows share that one horizon.

Every policy field is explicit. Supported paths are `shock_then_hold_native_quotes_v1`
and `elapsed_linear_native_quotes_18_to_even_v1`. The latter scales each terminal
native primitive move by elapsed UTC microseconds and rounds that native quote
offset once to 18 fractional places, half-even. Each event and horizon scenario
branches from the immutable opening graph; moves are never accumulated through
successive interpolation steps. Connected derived curves rebuild from their
affected primitives. Captured rates and calibrated volatility remain fixed under
`captured_rates_and_volatility_held_v1`; this profile supplies no rate or volatility
shock axis.

An actual fixing requires its exact selected final frozen source evidence. Missing
opening fixings cannot become forecasts. Projected fixings have separate types and
freeze only inside their own path after their event. A future's projected final
settlement freezes its explicitly selected native primitive for subsequent
dependent curves; ordinary daily margin preserves continuing exposure. Conflicting
final instants refuse. Projected final prices never become actual
`FuturesSettlementFact` instances.

Mark and official settlement sources remain separate. A futures projection selects
its scenario-event market explicitly in addition to the adopted actual settlement
policy. Matching quotation units cannot infer that choice. Global event ordering
respects declared prerequisite identities, including at the same instant. A
scheduled time before opening does not prove that a prerequisite occurred; the
opening adapter must retain its completed event evidence.

Residual positions use ordinary `ValuationPortfolio`, Instrument/Side PV and the
same immutable connected scenarios. Projection-marked state cannot enter an actual
valuation environment. A future margin event transfers its rounded amount to a
separate cash contribution and resets its path-local basis. Final cash settlement
removes its future exposure while unpaid cash remains a cash instrument. Physical
final settlement requires a qualified delivery handoff rather than the cash-final
adapter.

The explicit `retain_generated_delivery_until_observed_performance_v1`
disposition retains a newly projected physical-futures delivery obligation under
the original economic owner and binding. Final VM uses the shared margin
arithmetic; the shared product-owned final-delivery plan supplies an ordinary
signed acquisition/dispatch obligation at that final price. No native owner,
stock, title, performance or principal payment is created. The delivery mark
remains in the complete prepared factor union through the horizon. Deferred
physical value and consideration use the selected captured currency term
structure when the saved terms require carrying. A projected option exercising
into a physical future follows the same final-delivery adapter.

The handoff requires an explicitly admitted delivery market. A foreign definition
is available only through the selected full physical-value contract and its exact
captured source graph, described below; no matching price or unit implies that
source. A source-known physical final requires its exact native obligation
identity and complete performance descendants, and is unavailable to this
hypothetical-only handoff until that connected native attachment is prepared.
Existing independently owned gas uses its separately selected native projection
profile. A delivery date alone never grants title or schedules performance for a
newly generated obligation.

Each projected holding carries only its own valuation bindings, accounting facts
and instrument discount provider from the source portfolio. Generated residuals
receive their exact new instrument's provider. Ordinary portfolio validation
continues to reject unrelated bindings rather than weakening ownership checks for
mixed product scopes.

The event-aware Risk view materializes explicit server-offered policies and the
complete source/factor union before calibration or calculation. Its historical
and Monte Carlo requests retain the backend's full factor-column order; the
factor-free method sends explicit null history/simulation and an empty factor
array. Source and calculation receipts must match the submitted context, scope,
pricing policy, lifecycle policy, horizon and implementation version. UTC wire
identity preserves sub-millisecond digits; dates shown to the user use the
selected display zone.

Queued submissions retain their exact actor-owned request identity across lost
responses and header changes. Late reads cannot restore another actor or scope.
Reports display backend economic tails, ordinary residual/cash reconciliation and
a separate no-shock comparison diagnostic without browser financial arithmetic.
Owned-browser presentation checks qualify explicit settings, complete sampled
envelopes, signed tails and uncertain-response recovery. The native worker and
full-application qualifiers below exercise those consumers independently.

Cash disposition selects hypothetical payment or continued outstanding cash.
For standard payments, `utc_payment_day_v1` keeps cash outstanding throughout
its contractual UTC date and places hypothetical discharge at the following UTC
midnight. Same-day fixings and completion precede that boundary. Exact-instant
contracts discharge at their selected due instant. Neither assumption records an
actual payment or creates a contractual deadline. Future unpaid contributions use ordinary
`TimedCashPayment` PV. Period cash is either nominal or accumulated to the horizon
using the exact ratio of captured source discount factors. Currency curves require
an explicit captured term-structure capability, exact-instant timing and retained
identity; a scalar payment factor cannot define accumulation. One currency uses
one selected accumulation curve version across all market partitions. There is no
implicit currency conversion.

`LifecycleCurrencyDiscounting` prepares the complete native rate term structure
once and resolves event-created due keys without further source reads. It uses
the existing exact-instant interpolation and conditional ratio conventions at
the explicit horizon clock. Factor evidence retains the original source snapshot,
the new calculation instant, exact curve version, full tenor geometry and the
required native pillars. Equal rates do not erase required pillars. The source-only
discount contract remains separate; it does not silently acquire a clock roll.

Absolute economic P&L is horizon residual PV plus horizon-valued period cash minus
opening PV. The no-shock result retains time and carry. Historical and Monte Carlo
risk reduce complete economic wealth observations with the existing exact signed
empirical quantile/tail reducer. A separately labelled market-only diagnostic uses
no-shock horizon wealth as its comparison value. It never replaces the economic
measure or removes deterministic drift from it. Gain-only tails may have negative
VaR or expected shortfall. A failing holding or path fails the complete run; rows
are never dropped or resampled. Event-aware parametric risk is unavailable until
separately qualified.

Preparation exposes the entire transition/residual factor union and connected
manifest before history capture. Retained history must cover those exact native
coordinates and the certified opening forecast. Monte Carlo uses the existing
counter-addressed generator under its explicitly selected economic valuation
profile. Complete owner/currency scope and all path indices enter reduction.

The managed checks independently cover derived-curve interpolation and fixing
freeze, futures margin cash plus residual conservation, final future freezing for
a dependent forward, nominal/accumulated and future unpaid cash, native owners,
signed empirical tails, deterministic carry, full Monte Carlo paths and refusal
of failed paths. Native source resolution, physical delivery adapters and retained
worker/HTTP/UI integration have their own executable qualifiers below; pure
numerical checks alone establish none of those source or authorization contracts.

The native retained-job boundary has a dedicated economic envelope for the
three qualified methods. It verifies the source-known horizon against the native
session reader, retains explicit policy and calibration evidence, and forbids
split or mixed-method requests. Deterministic custody admits zero selected
observations and no history; sampled custody requires the complete native factor
set. Canonical retained-axis order is independent of calibrated history-column
order, which managed preparation revalidates.

Worker binding retains the selected business date separately from the UTC
valuation instant. Native read grants require the exact owned job attempt;
selected gas scope additionally requires current represented-user, delegation
and service gas-read authority. Read-only workers receive no lifecycle writer
operation. Native source readers pin owner/binding, context, calculation source
instant, book scope and selected profile to the retained job's source-resolved
holding and accepted option-child closure. Delivery-bearing adopted or option
expiry policies require gas-read authority before inventory exists. Generic gas
history reads for an explicit trade subset remain refused until its independent
native descendants have an account-bounded source adapter.

Binding captures the admission clock and security generation before its first
epoch wait, then pins the original service, user, delegation and lease deadline;
a future successor grant cannot revive an expired source read. These database
custody checks complement the whole-product numerical worker replay described
below.

An owned native gas fixture now runs the actual managed historical and Monte
Carlo workers from frozen admitted binaries. Each complete report, including
native owner attribution, horizon, history and source evidence, equals the
interactive report. A worker without selected gas authority cannot claim the
job. Cancellation while the managed worker waits on its first native source
read ends cancelled without a result. No market observation, trading publication
or owned position is written by these calculations. This qualifies the
single-definition native-gas baseline. Mixed definitions and additional product
branches use their separate managed-worker qualifiers below. Profile completion uses
the exact source context, opening instant and original source-read deadline;
workers receive no interactive-preview capability.

An owned full-application browser check now exercises the same native-gas
baseline through the actual API and managed worker, without substituting API
responses. It selects every lifecycle policy, prepares the complete source and
aligned history, checks the independently calculated signed tail, queues a job,
reopens its completed report after a full reload, and changes the display zone
without another financial calculation. The economic form owns its busy and
method-specific control state; static-risk synchronization preserves the
selected economic report address and captured context.

The actual managed-worker qualification also covers a pending financial swap
under historical and Monte Carlo economic risk, plus activation of an accepted
future-effective swap payment under deterministic economic risk. Complete
interactive reports and retained worker results match exactly, with no source
writes. The native configuration reader resolves option and swap profile heads
at the captured source before matching held terms. Worker requests retain the
exact trade, origin revision, context, opening instant and business date; forged
arguments refuse. Knowledge-only swap cash retains its original source-read
admission rather than acquiring an interactive action-read capability.

Owned-gas report labels retain the saved account code and original applied
evidence business reference. Physical obligations and principal also retain the
exact causal future's existing readable trade reference. Label enrichment
operates only on already-authorized returned memberships, including surviving
fees after stock is consumed, and rechecks the original gas-read deadline.
It changes no quantity, market selection, native ownership or payment history.

The pure listed-option adapter retains the source calibration and open signed
remaining lots. At expiry it applies the exact versioned automatic exercise rule
or the captured contrary instruction, then replaces the option with the ordinary
linked future at strike. Later margin events use the same futures difference and
rounding calculation. Premium cash is a separate original holding. A physical
linked future requires qualified delivery admission before any path is sampled.
Instruction cutoffs and expiry are separate boundaries: the held option remains
priceable after its instruction cutoff and before expiry, at its held volatility.

The pure dated financial-swap adapter uses the existing Side payment cash,
averaging, reset applications and exact membership/quantity scaling. Path-local
fixings lock once; projected contractual cash is rounded under the selected
gross-payment convention. Separate hypothetical binding state is rejected by
actual valuation and native settlement. Source-known native determinations and
their complete correction chains remain actuals, including future-effective
determinations visible at the selected knowledge cutoff. Their exact amounts
apply at the recorded effective instant and take precedence over a same-instant
projected fixing. Knowledge-only payment history retains native composite
allocation identities, reconciles opening allocations and bounds every effective
allocation prefix by its exact accepted contribution. Future actual payments are
reserved against hypothetical discharge and recognized once at their own instant.

A fully prepared scope with no variable factors may use the separately labelled
deterministic economic result. Its single exact point mass includes signed time
and carry risk; the market-only diagnostic is zero. It creates no historical
dates, covariance calibration or random paths. This admission is never a fallback
for failed dependency preparation or missing prices/history.

The horizon identifies the native close-session primary key: catalog, code and
exact version. It uses no synthetic session UUID. Native certification of that
configuration and complete next-close calendar resolution remain source-reader
responsibilities.

The native horizon reader records immutable close-session publication links in
the existing certified trading publication stream. Existing published settings
receive their real migration commit time, with no historical backdating. Reads
bind the exact source context, verify the selected governing opening version and
follow only the source-known effective session schedule to the next close.
Every consumed calendar/clock/version is authorized and retained; unrelated
versions are excluded from evidence. Missing coverage, an unreadable consumed
version or an ambiguous/nonexistent cutoff refuses rather than rolling the date.
Managed source admission retains the original read deadline through commit.
Owned native checks cover old-cutoff refusal, migration receipts, calendar
holidays/weekends, a known future version change, an unreadable unused version,
source-context binding and successor-grant deadline refusal.

Qualified connected economic components can update one flat immutable member
map atomically, as required when delivery consumes an explicitly linked owned
stock position. `Compose` builds the sole valued residual/cash aggregates, and
preparation and every transition verify those aggregates against all members.
Members retain their original economic owners, opening PV, residual PV and cash;
results and empirical tail contributions remain separate for each owner. Nested
states are never priced again. Source-known payments and native cash evidence
cannot move between members during a hypothetical path. Current composition
admits one book, currency and source graph; cross-source funding requires its own
qualification. The managed independent oracle transfers 100 units of value
between two members and retains their -100/+100 P&L with zero portfolio loss.

Market input lifetime is separate from the full preparation dependency union.
Each adapter declares the last possible read of each selected projection market;
fixing an index does not keep its mark live until a later cash payment. Expiring
native inputs require the selected curve's supported frozen-final relationship
or a declared event-market final transition. The projected native primitive is
capped at that exact final instant even when no future is held. Source-known
native finals are separate immutable evidence and override the native primitive
at their effective instant before all same-instant consumers, including no-shock
paths. Unqualified live-input crossings refuse before sampling.

The managed option and futures adapters replay source-known future-effective
native events without manufacturing future snapshots or accepted fact types.
Native future cash memberships remain inactive source evidence until their
occurrence; complete actual payment history is retained at opening and only the
uncommitted remainder follows the selected projected payment policy. A known
partial option exercise preserves its already-booked linked future and the
remaining right separately; a hypothetical price move cannot undo that accepted
exercise. Independent managed checks cover signed wealth and payment conservation.

The API economic source preparation entry point and retained-union result are
implemented as an integration checkpoint. It reads the certified next close,
revalidates accepted past margin sources, prepares all declared transition inputs,
and preserves each selected full-model option's original source calibration,
provider and receipt. Its premium retains the original carrying for the exact
held owner/binding. Exact-instant future-margin and asset/principal carrying are
separate declared inputs. The legacy unselected diagnostic keeps its existing
source-preparation contract. Native financial-swap source preparation retains exact per-period settings,
completion boundaries, source-known determination/payment chains and contractual
price contexts. An owned PostgreSQL check qualifies no-shock wealth and replay of
the complete retained market manifest. Native option histories and their linked
future histories are orchestrated by the same entry point. Separate native,
full-application and retained-worker checks below qualify the selected option,
gas and physical-final source paths.

The projection contract requires an explicit input-expiry treatment. The
`declared_curve_expiry_policy_v1` choice honors saved curve edges and refuses an
unqualified gap between native expiry and a later final event. The
`freeze_selected_native_mark_at_expiry_v1` choice caps selected event-market
primitives at their native expiry and carries that mark to a later hypothetical
final. Derived `RequireLive` edges remain strict under either choice. An actual
known final changes the market only at its own effective instant. A mark-expiry
valuation transition preserves the original basis and quantity, creates no cash
and records no accepted margin. Independent checks cover residual PV within the
gap, later cash, unchanged basis and a known final that cannot be read early.

Input-use declarations are retained during preparation and enforced at runtime.
Every component covers its own full dependency union; a later consumer cannot
read past a declared last-use time or create a missing earlier projected fixing.
The public projection request also requires an explicit gas profile selection
array, including `[]` when none is selected. The qualified native source and
connected projection adapters require exact complete selected account coverage.

Knowledge-only final-input reads retain the exact projection market, official
source, native series, final occurrence, source context and certified correction
ancestry. They do not move the opening business clock or alter captured snapshot
selections. A narrow read boundary rechecks saved projection profiles under their
original source and current reference authority; private action-write helpers
remain private. The exact-instant currency provider also supports ordinary source
PV without a fictitious clock roll, while every forward roll requires its
explicit policy. An explicitly undiscounted swap with nominal cash needs no unused
currency curve mapping.

The economic session chooser reads only the source-known published version that
governs the opening business day. It selects governing versions before applying
current reference/definition visibility, so an unreadable head never falls back
to an older readable version. Future-effective versions and settings published
after the selected cutoff are absent from choices. Choice reads retain the same
original source admission through commit as the selected horizon calculation.

The pure projection evaluator can retain several exact native market graphs in
one connected economic component. Each dependency, residual and cash membership
uses its explicitly declared source; native prices, currency carrying inputs and
source certificates are not relabelled across definitions. A cash or residual
route, once admitted, remains attached to its original identity through the path.
Missing sources, inconsistent shared primitive facts and unassigned final-input
declarations refuse preparation. Independent two-definition checks qualify
ordinary residual PV and exact future-cash carrying through this router. Native
physical source assembly and accepted performance activation have separate native
and worker qualifiers below.

A native adopted cash future is also qualified through actual retained historical
and Monte Carlo workers. The source adapter rechecks the exact selected context,
opening instant and original read deadline through the same native source-read
contract used by state materialization. Read-only workers acquire no interactive
preview grant. Complete worker reports match interactive results under frozen
binaries, with no appended market, margin or trading facts.

Gas authority follows the selected valuation consumer. A saved expiry action
profile alone does not add Gas permission to an ordinary vanilla option or
execution-value job. Economic physical continuation, an explicitly selected
physical option model and native physical-future state retain the exact causal
Gas requirement for both actor and service. Ordinary nonconsumers return before
reading continuation policies; source scope, original deadlines and result
revocation checks remain in place.

Accepted past futures margin is financial evidence even when its official source
is absent from the retained variable graph. The economic adapter uses the native
adopted trade/binding and policy to read the complete certified correction history
for required past occurrences. It does not grant workers raw knowledge-receipt
access or invent variable factors for those facts. The response retains exact
occurrence IDs and the original source-admission deadline, rechecked before and
after the read and at application commit. A conservative 16 MiB encoded budget
includes observations, publication times, occurrence IDs and the envelope; an
oversized complete response refuses before array aggregation, without truncation.

Close workers retain one transaction-owned database adapter per phase and read
each native close's exact definition/reference source. An unconfigured gas probe
must prove the captured scope empty; it retains the original independent business
source admission through the explicit preflight-to-publication context transition.
Configured gas keeps its full gas-specific scope admission. Original source
deadlines remain commit checks. The generated-close worker, report recovery and
15 real-browser checks exercise this publication boundary.

Native market inputs can be shared by separate financial source graphs. A
coordinate has one owning native source; copied source points and native built
outputs require identical complete source calculations and observation evidence.
The common shock reaches each exact current point in every consuming graph.
Historical frozen samples retain their own identities. Factor union rejects
conflicting native declarations and merges only declared curve reachability.
Independent checks qualify A/B shocks, hedge cancellation, joint scenarios and
derivatives, historical freezing and substituted upstream evidence.

Margin occurrence selection uses the adopted dated schedule and its explicit
execution-opening convention. A held valuation requires the complete accepted
causal prefix; a completed final has no next due. An exact new include-opening
inception may retain its first pending occurrence, while older missing events
refuse. A rational lattice execution offset selects the same saved due without
creating an event or rounding a node to a fabricated business instant.

An ordinary discount declaration may select an exact independently admitted
source snapshot. Foreign sources retain the opening instant, market cutoff and
certified knowledge context; a definition identifier alone is insufficient.
Providers receive that original source and return its unchanged evidence. Source
identity participates in declaration and reuse fences. Omitting this optional
field preserves the existing primary-source-only contract. Independent A/B
exchange checks include nonunit quantities, shared price children and refused
source or provider-evidence substitutions.

Volatility-fit jobs retain their established actor publication permission and
the worker service's existing risk-read permissions. Other risk jobs retain
scenario permission. Both purposes preserve original grant deadlines through
first-wait admission; a preexisting successor grant cannot revive an expired
operation. Guarded native checks qualify this split without adding role grants.

The selected `flat_reference_to_next_saved_margin_due_v1` unit valuation prices
pending VM at the next exact scheduled due using the captured currency carrying
provider. Native basis, quantity and complete occurrence prefix remain separate
retained inputs. Scenario transitions advance only that immutable valuation
prefix; no accepted determination is manufactured. The nominal legacy valuation
remains unchanged. Independent checks qualify signed pending value, negative-rate
discounts, same-clock reset plus cash, intermediate daily reset and explicit
no-shock funding carry. The native portfolio profile below selects this law
explicitly.

An explicit captured price source binds a declared request to its original
admitted graph point. Exact expression and resolved dependency evidence must
match through the complete subgraph, including foreign and historical source
samples and their original certified inputs. Independently admitted partial
views may cover the same exact source frame; another certificate cannot.
Structural comparison is reusable across immutable price scenarios and checks
no shocked level against its base. Source authorization remains operation-owned.

The selected `vm_plus_declared_delivery_basis_v1` future unit value combines
pending VM with an unfixed delivery exchange under one original held binding.
The exact adopted profile, explicit deliverable/proxy mark interpretation,
captured asset graph and physical/principal carrying inputs are required. The
product records margin and delivery-basis components without adding a booked
holding, title, cash or accepted event. Independent A/B, signed, nonunit,
negative-price and distinct-due checks qualify the bounded ordinary value and
its no-event horizon reuse. A foreign dependency in that unit must match its
independently admitted source graph exactly.

The pure future projection now retains that full opening measure through final
margin. The future becomes a locked-principal ordinary obligation, while VM
cash survives once at its own due. Independent same-instant checks include a
discounted unpaid VM claim plus surviving delivery value, both signed paths,
separate source definitions and no title at expiry. Physical projection requires
the selected full valuation contract even when the horizon precedes final.
Source-known native obligation/performance activation, user-facing full-model
settings and selected physical options are qualified by the separate consumers
below. An A-only option calibration cannot silently choose a delivery-basis model.

The pure `gas_accepted_quantity_lifecycle_projection_v3` adapter preserves exact
source-known stock reservations, releases and consumptions together with their
linked quantity-obligation reductions and native receipt owners. Actual events
precede hypothetical events at the same instant through explicit prerequisites.
Remaining obligations are checked after the accepted event prefix. Full performance
at due requires an explicitly stated remainder equal to the opening quantity less
accepted discharges at or before due. Oversized or undersized allocations and later
accepted discharges refuse; no quantity or supply list is silently resized. The
original knowledge cutoff remains fixed.
This version does not infer funding for an independent future title or loan.

Each hypothetical stock use must leave enough stock for the complete remaining
accepted resource schedule. The check replays the chronological reserve, use and
release operations, so released stock may be reserved again without counting the
same units twice. Depleted stock with a later accepted reservation release keeps
an explicit zero-valued, projection-only resource binding. It has no commodity
mark dependency, admits only zero quantity and disappears after its final
release. Independent tests cover partial repayment, loss, distinct receipt
ownership, actual-first ordering, expired marks after depletion and refusal to
suppress nonzero value. Native saved profiles require an explicit cashout array,
including an empty array for a quantity-only selection. First-outcome retries,
same-fact acknowledgement and older-version acknowledgement preserve the
current selected revision. Native source assembly, full API and retained workers
qualify this version for the exact supported continuation contracts below.
The native `native_futures_economic_remaining_value_v2` portfolio profile requires
the exact pending-VM law and an explicit per-held-binding physical mark
interpretation. Its empty physical selection is valid only for a scope without
physical futures. Missing, extra or duplicate selections refuse. The established
nominal native-margin diagnostic retains its original version and wire shape.

The full profile resolves each asset source from the complete captured source
matrix, then prepares its original graph before portfolio or economic valuation.
A second source may supply an input graph without an inventory holding. It
retains its exact reference pins, observations, native rates, snapshot and
calculation context. Ordinary PV and economic opening value use the same
product-owned model; the original held owner and binding appear once. Source
final declarations and aligned history retain both native market partitions.

Owned native checks qualify a funded cash future and a physical future with
independently marked and discounted asset source. The latter independently
checks the VM, asset and principal legs and separate A/B scenario effects.
Actual historical and Monte Carlo workers reproduce their complete interactive
reports from frozen binaries and exact retained history, without financial
writes. Cash-only workers need no gas permission; physical consumers retain
represented-user and service gas-read requirements. The physical checks also
refuse an omitted source matrix part and missing or unheld binding settings.
Native API activation of accepted physical final obligations, title, funding stock
and principal descendants is qualified by the connected physical consumer below. A selected trade-only
full-value scope after accepted physical final refuses rather than omitting
independent physical ownership.

The composable pure future adapter also accepts an explicitly selected native
final-to-obligation link. Its source clock, exact future and delivery owners,
saved policy/profile, original quantity, full terminal price unit and complete
initial-to-current final ancestry must agree with the retained accepted margin.
The final transition activates that native obligation identity rather than
creating a second hypothetical holding. Actual final observations freeze their
shared native input at their own effective instant. Independent checks cover
corrected lineage, substituted units/owners/receipts and a dependent late price
read under a market shock. Native authorization and complete performance,
funding-stock and principal composition remain source-coordinator obligations;
this pure fact establishes no title or bank payment.

The pure physical continuation composes the original future, its native delivery
owner, received inventory, identified funding stock and principal cash as flat
economic members. Its final event applies VM before activating the real ordinary
locked-principal delivery instrument. The shared gas quantity engine alone
applies accepted discharges, title receipts, reservations and consumptions;
received stock can subsequently fund a native loan return. No internal delivery
cash or second stock mutation is added. Each mark retains an explicitly selected
original source under the same financial clock and knowledge cutoff.

Independent checks cover signed partial performance, foreign inventory marking,
native receipt followed by loan return, and exact principal origin/due ordering.
Retired title has no quantity effect; original cash, offsetting claims and
recorded payments survive under the verified sealed principal history.
An already-due claim activates unpaid at its actual later origin; a payment is
never moved backward. Principal carrying is an explicit supplied input. Native
source assembly and complete worker replay are qualified separately below for the
full product path. The pure wrapper admits exact arrays of future or already-active
delivery parents in one quantity engine. Each parent retains independent native
ownership and principal; shared stock is consumed once. Retrospective final-price
corrections retain the original final instant while reconciling all source-known
later title movements by their immutable publication and knowledge receipts.

Ordinary cash valuation can retain a carrying provider per exact held owner and
binding when memberships share one currency/due instrument. Its scope and
discount-input reuse fence stay separate; position subsets retain only their
selected inputs. An absent binding selection preserves existing shared-provider
behavior.

The explicitly selected `gas_owned_mark_to_market_v2` policy requires
`saved_delivery_profile_principal_carrying_v1`. Its native source reader enriches
only already-authorized principal memberships through their immutable obligation,
profile and account foreign keys. The selected profile must be known at the
original source cutoff; the read retains its original authority deadline.
Nominal principal uses an explicitly undiscounted factor of one. Curve-carried
principal uses the captured currency curve of its retained delivery market.
Fees and other cash keep their existing currency-default treatment. The ordinary
measure is named `gas_owned_saved_profile_present_value_v2`; the prior v1 policy,
wire and measure retain their existing semantics.

The economic source assembler preserves the selected binding provider, including
nominal principal without demanding an unused residual rate curve. Portfolio-wide
cash accumulation remains a separate explicit selection. Native qualification
covers nominal and curve principal, surviving payments, source-lineage refusals
and the backend policy choice. Nominal native holdings also value unchanged with
all rate observations removed from their selected source. Residual demand follows
each cash membership's recorded net state at the opening and horizon, including
known refunds. Offsetting flows do not create an artificial residual rate need;
their separate actual cash amounts retain the selected accumulation treatment.
The native coordinator below composes accepted physical activation and connected
multiple-parent resources under that selected carrying contract.

The native source coordinator prepares already-active delivery obligations and
source-known future title, identified short supply and principal changes together.
One connected quantity engine owns the stock transitions; original future and
principal components are absorbed only by exact native owner/binding identity.
New native stock and cash descriptors supply labels and zero opening value without
creating financial positions. Independent native checks reconcile each signed
obligation, stock lot, rounded principal membership and latest bank allocation.
Historical and Monte Carlo workers replay the exact interactive reports under
read-only authority, frozen engine binaries and unchanged financial records.

An accepted-final original future requires no physical mark selection and no
obsolete unfixed asset mark. The required selection set contains exactly the
unfinished native physical future bindings; completed or foreign entries refuse.
Its surviving VM cash remains ordinary native cash; complete wealth still
requires the independently owned delivery, stock and principal scope. Foreign
physical routes can reuse an already-prepared original market partition as well
as an input-only partition. Both require the exact source certificate, native
graph and complete declared bindings. Independent A/B native checks and workers
cover these routes and reject missing or substituted sources and bindings.

The active-parent fixtures cover both one source and independently selected A/B
definitions. The latter retains a nonzero A rate and an explicit zero B rate,
then values native title receipts, identified short dispatch and unpaid principal
on B. Each native owner's ordinary opening, residual wealth and B-only shock are
checked independently. Missing or substituted B graphs refuse, and read-only
historical and Monte Carlo workers reproduce the complete report. Selected
physical-option continuation is qualified separately below; its real application
browser flow is recorded in [the delivery contract](lifecycle-delivery.md#typed-native-gas-forms-and-full-application-qualification).

The fully performed-parent qualifier completes both signed delivery obligations
through the reviewed business operation and consumes all identified stock. Its
later source contains surviving native nominal cash with no price or rate pins,
quantity assumptions or placeholder holdings. The explicit v2 contract omits
residual carrying inputs for accepted-final futures while retaining their cash;
the established v1 contract retains its prior input requirements. A deterministic
read-only worker replays the exact cash-only report without financial writes.

Close workers retain one transaction-owned database adapter per phase and read
each native close's exact definition/reference source. An unconfigured gas probe
must prove the captured scope empty; it retains the original independent business
source admission through the explicit preflight-to-publication context transition.
Configured gas keeps its full gas-specific scope admission. Original source
deadlines remain commit checks. The generated-close worker, report recovery and
15 real-browser checks exercise this publication boundary.
The source-before-final native qualifier opens one minute before the real final
occurrence at a later explicit knowledge cutoff. No accepted opening margin or
physical holding is invented. The path activates the exact already-accepted
native obligation and VM cash at the final event, with later principal/title facts
still governed by their original dates. Every original owner's economic opening
matches its selected ordinary PV. Historical and Monte Carlo worker reports
match the interactive source exactly, under both the pre-final and active-parent
fixtures, without recording financial events during projection.

The full native valuation profile also requires a qualified option funding law
for cash-underlying options. A separate engine check holds the price, clock and
quantity fixed: two 10,000-unit calls at A=3 and K=2 retain a vanilla intrinsic
diagnostic value of 20,000, while their selected next-margin-due cash-future value
at a .95 factor is 19,000. These measures cannot be substituted at exercise.
The explicit `cash_futures_option_reference_strategy_v1` model and separate
`cash_futures_option_reference_value_v1` API container qualify the cash-underlying
consumer without asset terms or Gas authority. Its selected binding retains the
qualified cash future, exact saved margin occurrences and captured funding inputs;
both supported cash-margin policy versions require no delivery terms. Source-due
VM uses an explicit factor of one. A held path crossing an earlier daily margin
may change the funded value before expiry: the independent case moves from
19,000 to 16,000, then retains 16,000 through the expiry handoff and reset.
No early exercise fact or compensating cash is inferred from the valuation tree.
Missing a complete selected cash-model binding still refuses full-profile
preparation with `projection_cash_option_value`; legacy vanilla and native nominal
diagnostics keep their separate versions and wire contracts. Solved-volatility,
nonflat-rate and intraday source checks preserve original ordinary PV, calibration
and premium receipts. Native historical/Monte Carlo workers and the real A-only
application flow qualify complete retained replay without financial writes.
Selected cash and physical reference-strategy bindings explicitly withhold
unqualified static derivatives; full scenario revaluation does not fall back to
vanilla option Greeks.

Selected physical options retain their reference-American valuation strategy and
the explicit held-right lifecycle event policy separately. Projection activates
accepted native early exercise, assignment and expiry outcomes without applying
the pricing tree's stopping decisions as new events. A full close removes the
parent right; each exact native child has its own economic owner and certified
parent-event prerequisite. The selected mark interpretation applies to those
children and is validated again against each child's adopted delivery profile.
Hypothetical expiry retains the contractual parent owner and selected profile.
Missing a selected full-model binding refuses at preparation rather than falling
back to vanilla reference value.

The source assembler retains the parent's current asset source and every native
child's original source independently. A newly needed child source must occur in
the explicit complete input matrix and retain its original snapshot, graph,
authority and declared bindings. It creates no opening holding. Actual native
checks cover the right and premium, the child before, at and after full accepted
exercise, and an independent funded VM plus asset/principal exchange oracle.
Separate cases use one saved asset source or distinct current-parent and native
child sources with different prices and rates. Missing or substituted child
sources refuse. Historical and Monte Carlo read-only workers reproduce each
complete report and source union with frozen binaries and no financial writes.
Across-time no-shock P&L may include time, known events and the choice to retain
the right while its valuation model would prefer exercise; no compensating cash
is inferred. Unit working-scale rounding remains disclosed separately.

A separate sealed synthetic past listing qualifies an accepted option exercise
through its same-publication native future adoption, later final margin and
observed physical title, identified supply and principal memberships. The source
retains the option premium separately. Independent owner/quantity/cash oracles and
both read-only full-revaluation workers reuse the ordinary physical coordinator.
The listing is explicitly synthetic; observed final facts precede the actual
knowledge receipt rather than relying on a future observation timestamp.
